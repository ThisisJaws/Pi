Audiere Readme
2002.09.06
Chad Austin (aegis@aegisknight.org)


Audiere is a convenient, high-level audio API that handles file I/O, decoding,
mixing, and sound output for you.  See tutorial.txt on how to get started using
it.  See the source code if you're curious how it works.

Audiere is licensed under the LGPL.
