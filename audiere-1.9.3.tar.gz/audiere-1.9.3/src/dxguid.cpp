#define INITGUID
#include <windows.h>
#include <mmsystem.h>
#include <dsound.h>
