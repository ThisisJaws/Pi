#ifndef AUDIERE_INTERNAL_H
#define AUDIERE_INTERNAL_H


#include "audiere.h"


#define ADR_EXPORT(ret)  ADR_FUNCTION(ret)


#endif
